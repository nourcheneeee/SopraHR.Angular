import { Component } from '@angular/core';
import { Employee } from '../employee.model';
import { EmployeeService } from '../employee.service';
import { Router,ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-employeedetailsemployee',
  standalone: false,
  
  templateUrl: './employeedetailsemployee.component.html',
  styleUrl: './employeedetailsemployee.component.css'
})
export class EmployeedetailsemployeeComponent {

  
  selectedEmployee: Employee | null = null;

  constructor(private employeeService: EmployeeService, private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    const employeeId = this.route.snapshot.paramMap.get('id');
    if (employeeId) {
      this.selectedEmployee = this.employeeService.getEmployeeById(+employeeId);
    }
  }

  goToHome(): void {
   
      this.router.navigate(['/home-employee']);
  }

}
