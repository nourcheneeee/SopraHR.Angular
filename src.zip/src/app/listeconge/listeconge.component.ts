import { Component, OnInit } from '@angular/core';
import { CongeService } from '../conge.service';  
import { Conge } from '../conge';  
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee.model'; 
import { Router,ActivatedRoute, RouterModule } from '@angular/router';


@Component({
  selector: 'app-listeconge',
  templateUrl: './listeconge.component.html',
  styleUrls: ['./listeconge.component.css'],
   imports: [CommonModule, FormsModule,RouterModule], 
})
export class ListecongeComponent implements OnInit {
  leaveRequests: Conge[] = [];  
  newLeaveRequest: Conge = { id: 0, EmployeeId: 0, typeConge: '', dateDebut: '', dateFin: '', statut: 'En attente' };  // Objet de demande de congé vide
  showLeaveRequestForm: boolean = false;  
  selectedEmployee: Employee | null = null;

  constructor(
    private employeeService: EmployeeService,
    private congeService: CongeService ,
    private router: Router, private route: ActivatedRoute
  ) {}


  ngOnInit(): void {
    const employeeId = this.route.snapshot.paramMap.get('id');
    if (employeeId) {
      this.selectedEmployee = this.employeeService.getEmployeeById(+employeeId);
    }
    /*this.loadEmployeeData();*/
    this.loadLeaveRequests();
  }
  

  loadEmployeeData(): void {
    this.selectedEmployee  = this.employeeService.getCurrentEmployee();
  }
  

  loadLeaveRequests(): void {

    this.leaveRequests = this.congeService.getLeaveRequestsByEmployeeId(1);  
  }


  toggleLeaveRequestForm(): void {
    this.showLeaveRequestForm = !this.showLeaveRequestForm;  
  }

  requestLeave(): void {
    this.congeService.addLeaveRequest(this.newLeaveRequest);
    this.showLeaveRequestForm = false;  
    this.loadLeaveRequests();  
  }

 
  cancelLeave(id: number): void {
    this.congeService.cancelLeaveRequest(id);
    this.loadLeaveRequests();  
  }
 
  
    goToHome(): void {
        this.router.navigate(['/home-employee']);
    }
  }
