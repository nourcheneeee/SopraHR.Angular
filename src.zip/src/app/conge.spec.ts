import { Conge } from './conge';

describe('Conge', () => {
  it('should create an instance', () => {
    expect(new Conge()).toBeTruthy();
  });
});
