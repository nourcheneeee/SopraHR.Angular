import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';  
import { Employee } from '../employee.model';  
import { CommonModule } from '@angular/common'; 
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';  
import { RouterModule } from '@angular/router'; 
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  standalone: true, 
  imports: [CommonModule, FormsModule,RouterModule], 
})
export class EmployeeListComponent implements OnInit {
  employees: Employee[] = [];  
  selectedEmployee: Employee | null = null;
  isEditing: boolean = false;

  constructor(private employeeService: EmployeeService, private router: Router) {}  

  ngOnInit(): void {
    this.employees = this.employeeService.getEmployees(); 
  }

  
  goToHome(): void {
    this.router.navigate(['/home']); 
  }
}
