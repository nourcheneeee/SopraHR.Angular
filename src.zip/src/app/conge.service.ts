import { Injectable } from '@angular/core';
import { Conge } from './conge';
import { Employee } from './employee.model';

@Injectable({
  providedIn: 'root'
})
export class CongeService {
  private leaverequests: Conge[] = [
    new Conge(1, 1, 'Maladie', '2025-02-01', '2025-02-05', 'En attente'),
    new Conge(2, 2, 'Annuel', '2025-03-01', '2025-03-10', 'En attente'),
    new Conge(3, 3, 'Sans solde', '2025-04-01', '2025-04-07', 'En attente'),
  ];

  private employees: Employee[] = [
    new Employee(1, 'ahmed', 'Dddd', 'Software Engineer', '2020-06-15', 'assets/ahmed.avif', '555-1234', 'ahmed.Dddd@soprahr.com','employee','abc'),
    new Employee(2, 'amir', 'Ssss', 'HR Manager', '2018-03-20', 'photo2.jpg', '555-5678', 'amir.Ssss@soprahr.com','admin','123'),
    new Employee(3, 'salma', 'yy', 'Designer', '2019-05-15', 'photo3.jpg', '555-8765', 'salma.yy@soprahr.com','employee','abc')
  ];

  constructor() {}


  getLeaveRequests(): Conge[] {
    return this.leaverequests;
  }

 
  getLeaveRequestsByEmployeeId(employeeId: number): Conge[] {
    return this.leaverequests.filter(conge => conge.EmployeeId === employeeId);
  }

  getLeaveRequestById(id: number): Conge | undefined {
    return this.leaverequests.find(conge => conge.id === id);
  }


  addLeaveRequest(conge: Conge): void {
    this.leaverequests.push(conge);
  }


  acceptRequest(id: number): void {
    const request = this.leaverequests.find(d => d.id === id);
    if (request) {
      request.statut = 'Validé';
    }
  }

  rejectRequest(id: number): void {
    const request = this.leaverequests.find(d => d.id === id);
    if (request) {
      request.statut = 'Refusé';
    }
  }

  
  cancelLeaveRequest(id: number): void {
    const index = this.leaverequests.findIndex(d => d.id === id);
    if (index !== -1) {
      this.leaverequests.splice(index, 1);
    }
  }

  getEmployeeById(employeeId: number): Employee | undefined {
    return this.employees.find(employee => employee.id === employeeId);
  }
}
