import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { CongeService } from '../conge.service';
import { Conge } from '../conge'; 
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-congedetails',
  templateUrl: './congedetails.component.html',
  styleUrls: ['./congedetails.component.css'],
  standalone: true, 
  imports: [CommonModule, FormsModule,RouterModule], 
})
export class CongedetailsComponent implements OnInit {
  congeDetails: any;

  constructor(
    private route: ActivatedRoute,
    private congeService: CongeService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const congeId = this.route.snapshot.paramMap.get('id');
    if (congeId) {
      this.congeDetails = this.congeService.getLeaveRequestById(+congeId);
    }
  }

  getEmployeeName(employeeId: number): string {
    const employee = this.congeService.getEmployeeById(employeeId);
    return employee ? employee.firstName + ' ' + employee.lastName : ' '; 
  }

acceptRequest(id: number): void {
  this.congeService.acceptRequest(id);
  this.router.navigate(['/gestionconge']);
}

rejectRequest(id: number): void {
  this.congeService.rejectRequest(id);
  this.router.navigate(['/gestionconge']);
}

}
