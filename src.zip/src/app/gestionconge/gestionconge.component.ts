import { Component, OnInit } from '@angular/core';
import { CongeService } from '../conge.service';
import { Conge } from '../conge';
import { Router, RouterModule } from '@angular/router';  
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../employee.service'; 
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-gestionconge',
  templateUrl: './gestionconge.component.html',
  styleUrls: ['./gestionconge.component.css'],
  imports: [CommonModule,RouterModule,FormsModule],
})
export class GestionCongeComponent implements OnInit {
  demandesConges: Conge[] = []; // Ensuring that demandesConges is typed as Conge[] (Array of Conge)

  constructor(
    private congeService: CongeService, // CongeService for leave management
    private router: Router, // Router for navigation
    private employeeService: EmployeeService // EmployeeService for employee data
  ) {}

  ngOnInit(): void {
    this.demandesConges = this.congeService.getLeaveRequests();
  }

  getEmployeeName(employeeId: number): string {
    const employee = this.employeeService.getEmployeeById(employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown';
  }

  acceptRequest(id: number): void {
    this.congeService.acceptRequest(id);
    this.demandesConges = this.congeService.getLeaveRequests(); 
  }

  rejectRequest(id: number): void {
    this.congeService.rejectRequest(id);
    this.demandesConges = this.congeService.getLeaveRequests(); 
  }

  showLeaveDetails(conge: Conge): void {
    this.router.navigate(['/congedetails', conge.id]); 
  }
}
