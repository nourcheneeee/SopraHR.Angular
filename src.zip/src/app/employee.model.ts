export class Employee {

  constructor(
    public id: number,
    public firstName: string,
    public lastName: string,
    public position: string,
    public hireDate: string,
    public photo: string,
    public phone: string,
    public email: string,
    public role:String,
    public password: string,
   
  ) {}
}
