import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true, 
  imports: [CommonModule, FormsModule],
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  loginError: boolean = false;

  constructor(private router: Router) {}

  onLogin(): void {
    if (this.username === 'admin' && this.password === '123') {
    
      localStorage.setItem('currentUser', JSON.stringify({ username: 'admin', role: 'admin' }));
      
      this.router.navigate(['/home']);
      this.loginError = false;
    } else if (this.username === 'employee' && this.password === 'abc') {
    
      localStorage.setItem('currentUser', JSON.stringify({ username: 'employee', role: 'employee' }));
      
      this.router.navigate(['/home-employee']);
      this.loginError = false;
    } else {
      this.loginError = true; // Show error if login fails
    }
  }
}
