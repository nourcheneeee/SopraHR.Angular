import { Injectable } from '@angular/core';
import { Employee } from './employee.model'; 

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private employees: Employee[] = [
    new Employee(1, 'ahmed', 'Dddd', 'Software Engineer', '2020-06-15', 'assets/ahmed.png', '555-1234', 'ahmed.Dddd@soprahr.com','employee','abc'),
    new Employee(2, 'amir', 'Ssss', 'HR Manager', '2018-03-20', 'assets/amir.jpg', '555-5678', 'amir.Ssss@soprahr.com','admin','123'),
    new Employee(3, 'salma', 'yy', 'Designer', '2019-05-15', 'assets/salma.jpg', '555-8765', 'salma.yy@soprahr.com','employee','abc')
  ];

  private currentEmployee: Employee | null = null;

  constructor() {}

  getCurrentEmployee(): Employee | null {
    return this.currentEmployee;
  }

  setCurrentEmployee(employee: Employee): void {
    this.currentEmployee = employee;
  }

  getEmployees(): Employee[] {
    return this.employees;
  }

  getEmployeeById(id: number): Employee | null {
    return this.employees.find(emp => emp.id === id) || null;
  }
  getEmployeeName(employeeId: number): string {

    const employee = this.getEmployeeById(employeeId); 
    return employee ? `${employee.firstName} ${employee.lastName}` : 'Inconnu';
  }
  addEmployee(employee: Employee): void {
    const newEmployee = new Employee(
      this.employees.length + 1,  
      employee.firstName,
      employee.lastName,
      employee.position,
      employee.hireDate,
      employee.photo,
      employee.phone,
      employee.email,
      employee.role,
      employee.password
    );
    this.employees.push(newEmployee); 
  }

  updateEmployee(updatedEmployee: Employee): void {
    const index = this.employees.findIndex(emp => emp.id === updatedEmployee.id);
    if (index !== -1) {
      this.employees[index] = updatedEmployee;
    }
  }

  deleteEmployeeById(id: number): void {
    const index = this.employees.findIndex(emp => emp.id === id);
    if (index !== -1) {
      this.employees.splice(index, 1);
    }
  }

  isAdmin(): boolean {
    return this.currentEmployee?.role === 'admin'; 
  }
}
