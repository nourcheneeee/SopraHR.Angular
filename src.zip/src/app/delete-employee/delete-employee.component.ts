import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service'; 
import { Employee } from '../employee.model';  
import { Router } from '@angular/router';  
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css'],
  standalone: true, 
    imports: [CommonModule, FormsModule], 
})
export class DeleteEmployeeComponent implements OnInit {
  employeeId: number | null = null;  
  employee: Employee | null = null;   
  employeeNotFound: boolean = false;  
  employeeDeleted: boolean = false;  

  constructor(
    private employeeService: EmployeeService,  
    private router: Router                  
  ) {}

  ngOnInit(): void {}

  loadEmployee(): void {
    if (this.employeeId) {
      const employeeToDelete = this.employeeService.getEmployees().find(emp => emp.id === this.employeeId);

      if (employeeToDelete) {
        this.employee = { ...employeeToDelete };
        this.employeeNotFound = false; 
        this.employeeDeleted = false;  
      } else {
        this.employeeNotFound = true;
        this.employee = null; 
      }
    } else {

      this.employeeNotFound = false;
      this.employee = null;
    }
  }

 
  deleteEmployee(): void {
    if (this.employeeId && this.employee) {
      const employeeIndex = this.employeeService.getEmployees().findIndex(emp => emp.id === this.employeeId);

      if (employeeIndex > -1) {
        this.employeeService.getEmployees().splice(employeeIndex, 1);
        this.employeeDeleted = true;
        this.employee = null;
        this.employeeNotFound = false;
        alert('Employé supprimé avec succès');

        this.router.navigate(['/employees']);
      } else {
        this.employeeNotFound = true;
      }
    }
  }
  goToHome(): void {
    this.router.navigate(['/home']); 
  }
}
